#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 descargar_fotos.py
